//ejercicio 41
let nombre="Waldo";
console.log(nombre);

//ejercicio 42
let edad="46"
console.log("Tienes " + edad + " años");

//ejercicio 43
var esEstudiante = true;
if (esEstudiante===true) {
    console.log("Eres estudiante");
} else {
console.log("No eres estudiante");
}

//ejercicio 44
let fruta="sandía"
console.log("mi fruta favorita es la " + fruta);

//ejercicio 45
let numero1= 120;
let numero2= 80;
console.log(numero1 + numero2);