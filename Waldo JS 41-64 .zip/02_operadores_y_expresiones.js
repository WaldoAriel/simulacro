
//ejercicio 46
let temperaturaCelcius = 32;
let temperaturaFarenheit = (temperaturaCelcius * (9 / 5) + 32);
console.log(temperaturaFarenheit);

//ejercicio 47
let precioProducto = 450;
let cantidadComprada = 7;
let total = (precioProducto * cantidadComprada)
console.log("total a pagar $ " + total);

//ejercicio 48
let radio = 20;
let areaDelCirculo = ( Math.PI * radio * radio);
console.log(areaDelCirculo);

//ejercicio 49
let num1 = 624;
let num2 = 287;
console.log(num1 > num2);

//ejercicio 50
let cadena1 = "Bienvenidos a ";
let cadena2 = "Santa Rosa de Calamuchita";
console.log(cadena1 + cadena2);